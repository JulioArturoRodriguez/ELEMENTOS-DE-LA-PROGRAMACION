/******************************************************************************************************************************
  SE INGRESA LA CANTIDAD DE HORAS TRABAJADAS Y LA CATEGORIA DE UN EMPLEADO.  CALCULAR EL SUELDO.
  SE SABE QUE EL VALOR POR HORA DEPENDE DE LA CATEGORIA, SEGUN:
  CATEGORIA 1: VALOR HORA $200
  CATEGORIA 2 o 3: VALOR HORA $250       CATEGORIA 4 , 5 o 6: VALOR HORA $280
*****************************************************************************************************************************/
#include <stdio.h>
#define VHA 200
#define VHB 250
#define VHC 280
main()
{
  int CAT, CANT, BAND;
  float VH;
  BAND = 0;
  printf("\n Ingresar categoria: ");
  scanf("%d",&CAT);
  printf("\n Ingresar cantidad de horas trabajadas: ");
  scanf("%d",&CANT);
  switch (CAT)
  {
    case 1: VH = VHA;
            break;

    case 2: case 3: VH = VHB;
                    break;

    case 4:
    case 5:
    case 6: VH = VHC;
            break;

    default : BAND = 1;
   }

    if (BAND == 0)
        printf("\n El sueldo es %.2f", CANT*VH);
    else
        printf("\n ERROR CATEGORIA");
}


