/**Confeccionar un programa que permita ingresar un car�cter alfanum�rico y
   determine e informe si lo ingresado corresponde a una vocal,
   con el mensaje �VOCAL�. y su correspondiente valor num�rico en ASCII **/

#include <stdio.h>
main()
{
  char LETRA;


  printf("\nINGRESAR UN CARACTER: ");
  scanf ("%c",&LETRA);
  if (LETRA ==  'a' || LETRA ==  'e'|| LETRA ==  'i' || LETRA ==  'o'|| LETRA ==  'u' || LETRA ==  'A' || LETRA ==  'E'|| LETRA ==  'I' || LETRA ==  'O'|| LETRA ==  'U')
       printf("\n SE INGRESO UNA VOCAL, SU VALOR NUMERICO ASCII ES %d", LETRA);
  else
       printf("\n NO SE INGRESO UNA VOCAL");
  printf ("\n\n");
}
