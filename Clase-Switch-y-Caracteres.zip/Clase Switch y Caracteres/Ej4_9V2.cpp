/**Confeccionar un programa que permita ingresar un car�cter alfanum�rico y
   determine e informe si lo ingresado corresponde a una vocal,
   con el mensaje �VOCAL�. y su correspondiente valor num�rico en ASCII **/

#include <stdio.h>
#include <ctype.h>
main()
{
  char LETRA,LETRA2;


  printf("\nINGRESAR UN CARACTER: ");
  scanf ("%c",&LETRA);
  LETRA2 = tolower(LETRA);
  if (LETRA2 ==  'a' || LETRA2 ==  'e'|| LETRA2 ==  'i' || LETRA2 ==  'o'|| LETRA2 ==  'u' )
       printf("\n SE INGRESO UNA VOCAL, SU VALOR NUMERICO ASCII ES %d", LETRA);
  else
       printf("\n NO SE INGRESO UNA VOCAL");
  printf ("\n\n");
}
