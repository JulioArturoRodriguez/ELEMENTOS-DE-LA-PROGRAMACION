#include <stdio.h>
main()
{
    int operacion;

    printf("\n 1- SUMA \n 2- RESTA \n 3- PRODUCTO \n 4- COCIENTE");
    printf("\n\n Ingresar OPERACION A REALIZAR ");
    scanf("%d",&operacion);
    switch(operacion)
    {
        case 1: printf("\n\t SE ELIGIO SUMA");
                break;
        case 2: printf("\n\t SE ELIGIO RESTA");
                break;
        case 3: printf("\n\t SE ELIGIO PRODUCTO");
                break;
        case 4: printf("\n\t SE ELIGIO COCIENTE");
                break;
       default : printf("\n ERROR OPERACION");
     }
   printf("\n\n\n");
}
